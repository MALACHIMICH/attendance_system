class MeetingRepoImpl {}
