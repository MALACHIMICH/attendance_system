// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'class_data_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$classDataHash() => r'dc0e153f4f15b593e53141b1a866ee831c4d661c';

/// See also [ClassData].
@ProviderFor(ClassData)
final classDataProvider =
    AutoDisposeNotifierProvider<ClassData, ClassDataSource>.internal(
  ClassData.new,
  name: r'classDataProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$classDataHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ClassData = AutoDisposeNotifier<ClassDataSource>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
