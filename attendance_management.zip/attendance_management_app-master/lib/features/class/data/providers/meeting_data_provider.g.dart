// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'meeting_data_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$meetingDataHash() => r'9724c58ed8c221a07113b259dc96ccd4e579416d';

/// See also [MeetingData].
@ProviderFor(MeetingData)
final meetingDataProvider = AutoDisposeNotifierProvider<MeetingData,
    MeetingDataSourceRepository>.internal(
  MeetingData.new,
  name: r'meetingDataProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$meetingDataHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$MeetingData = AutoDisposeNotifier<MeetingDataSourceRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
