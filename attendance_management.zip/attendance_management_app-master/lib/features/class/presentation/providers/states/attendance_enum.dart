enum AttendanceState { none, unMarked, marked }
