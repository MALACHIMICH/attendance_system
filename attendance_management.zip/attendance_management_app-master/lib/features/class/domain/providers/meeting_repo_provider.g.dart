// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'meeting_repo_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$meetingRepoHash() => r'098dc78d64934048212cceaa99d06cf8cb0f9933';

/// See also [MeetingRepo].
@ProviderFor(MeetingRepo)
final meetingRepoProvider =
    AutoDisposeNotifierProvider<MeetingRepo, MeetingRepoImpl>.internal(
  MeetingRepo.new,
  name: r'meetingRepoProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$meetingRepoHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$MeetingRepo = AutoDisposeNotifier<MeetingRepoImpl>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
