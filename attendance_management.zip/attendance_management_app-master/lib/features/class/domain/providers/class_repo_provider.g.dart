// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'class_repo_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$classRepoHash() => r'6428be32ae92908e46ba9ce2d255803a85e9b94a';

/// See also [ClassRepo].
@ProviderFor(ClassRepo)
final classRepoProvider =
    AutoDisposeNotifierProvider<ClassRepo, ClassRepository>.internal(
  ClassRepo.new,
  name: r'classRepoProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$classRepoHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ClassRepo = AutoDisposeNotifier<ClassRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
