// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'onboarding_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$onboardingHash() => r'd3bdc834cc604c12176ad7bfa0dc12f2eeb0ae8e';

/// See also [Onboarding].
@ProviderFor(Onboarding)
final onboardingProvider =
    AutoDisposeNotifierProvider<Onboarding, int>.internal(
  Onboarding.new,
  name: r'onboardingProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$onboardingHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Onboarding = AutoDisposeNotifier<int>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
