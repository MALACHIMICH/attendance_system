// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'profile_data_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$profileDataHash() => r'27fd8d2cfcd481e91decb297054fe8a663bdaa8d';

/// See also [ProfileData].
@ProviderFor(ProfileData)
final profileDataProvider =
    AutoDisposeNotifierProvider<ProfileData, ProfileDataSource>.internal(
  ProfileData.new,
  name: r'profileDataProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$profileDataHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ProfileData = AutoDisposeNotifier<ProfileDataSource>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
