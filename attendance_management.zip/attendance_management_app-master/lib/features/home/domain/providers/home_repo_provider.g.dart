// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'home_repo_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$homeRepositoryHash() => r'3e8db802e1c07131dc4b07a860ed9274b4cfd797';

/// See also [HomeRepository].
@ProviderFor(HomeRepository)
final homeRepositoryProvider =
    AutoDisposeNotifierProvider<HomeRepository, HomeRepo>.internal(
  HomeRepository.new,
  name: r'homeRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$homeRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$HomeRepository = AutoDisposeNotifier<HomeRepo>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
