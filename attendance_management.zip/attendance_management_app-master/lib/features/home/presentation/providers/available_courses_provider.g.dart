// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'available_courses_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$getAvailableCoursesHash() =>
    r'c10a8972edb08fc72579d716dadbb34929c2e602';

/// See also [getAvailableCourses].
@ProviderFor(getAvailableCourses)
final getAvailableCoursesProvider = FutureProvider<List<Course>>.internal(
  getAvailableCourses,
  name: r'getAvailableCoursesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$getAvailableCoursesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef GetAvailableCoursesRef = FutureProviderRef<List<Course>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
