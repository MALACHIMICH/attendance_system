// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'course_data_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$courseDataHash() => r'3999f68395ecee952b7f46c0612d28cf4acaa49b';

/// See also [CourseData].
@ProviderFor(CourseData)
final courseDataProvider =
    AutoDisposeNotifierProvider<CourseData, CourseDataSource>.internal(
  CourseData.new,
  name: r'courseDataProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$courseDataHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CourseData = AutoDisposeNotifier<CourseDataSource>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
