// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'course_repo_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$courseRepoHash() => r'cae7792bd030df845c083c4db758786acd5edec5';

/// See also [CourseRepo].
@ProviderFor(CourseRepo)
final courseRepoProvider =
    AutoDisposeNotifierProvider<CourseRepo, CourseRepository>.internal(
  CourseRepo.new,
  name: r'courseRepoProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$courseRepoHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CourseRepo = AutoDisposeNotifier<CourseRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
