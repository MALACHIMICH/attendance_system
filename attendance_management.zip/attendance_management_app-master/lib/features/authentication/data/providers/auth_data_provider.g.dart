// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth_data_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$authDataHash() => r'01e5fa1e259f1d481b962f0148a24674653590ba';

/// See also [AuthData].
@ProviderFor(AuthData)
final authDataProvider =
    AutoDisposeNotifierProvider<AuthData, AuthDataSource>.internal(
  AuthData.new,
  name: r'authDataProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$authDataHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AuthData = AutoDisposeNotifier<AuthDataSource>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
