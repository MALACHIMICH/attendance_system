// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'gender_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$genderTypeHash() => r'3ed01c50e430a0b504407f1277b5db1b48f9ba89';

/// See also [GenderType].
@ProviderFor(GenderType)
final genderTypeProvider =
    AutoDisposeNotifierProvider<GenderType, GenderEnum>.internal(
  GenderType.new,
  name: r'genderTypeProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$genderTypeHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$GenderType = AutoDisposeNotifier<GenderEnum>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
