// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'create_user_state_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$createAccountUserTypeHash() =>
    r'e37b06c198c9eaf8de130724bedc811ff8e182ea';

/// See also [CreateAccountUserType].
@ProviderFor(CreateAccountUserType)
final createAccountUserTypeProvider =
    AutoDisposeNotifierProvider<CreateAccountUserType, UserType>.internal(
  CreateAccountUserType.new,
  name: r'createAccountUserTypeProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$createAccountUserTypeHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CreateAccountUserType = AutoDisposeNotifier<UserType>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
