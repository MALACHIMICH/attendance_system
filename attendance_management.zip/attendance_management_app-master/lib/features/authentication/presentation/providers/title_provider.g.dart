// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'title_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$titleTypeHash() => r'8afdade38d436132f921364a30538766090f442a';

/// See also [TitleType].
@ProviderFor(TitleType)
final titleTypeProvider =
    AutoDisposeNotifierProvider<TitleType, TitleEnum>.internal(
  TitleType.new,
  name: r'titleTypeProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$titleTypeHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$TitleType = AutoDisposeNotifier<TitleEnum>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
