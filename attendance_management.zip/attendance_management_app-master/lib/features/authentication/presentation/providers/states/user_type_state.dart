enum UserType { none, lecturer, student }

enum GenderEnum { none, male, female }

enum TitleEnum { none, Dr, Mr, Mrs, Miss }
