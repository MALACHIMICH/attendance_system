// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth_repo_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$authRepoHash() => r'1f3e3117503a4233f401abdd3fc430078eff3a46';

/// See also [AuthRepo].
@ProviderFor(AuthRepo)
final authRepoProvider =
    AutoDisposeNotifierProvider<AuthRepo, AuthenticationRepository>.internal(
  AuthRepo.new,
  name: r'authRepoProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$authRepoHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AuthRepo = AutoDisposeNotifier<AuthenticationRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
