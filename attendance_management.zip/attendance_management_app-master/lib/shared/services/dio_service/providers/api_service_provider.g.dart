// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'api_service_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$apiServiceMethodsHash() => r'b4e49fbf617cecec30fff4eb9d99cdc44ed15640';

/// See also [ApiServiceMethods].
@ProviderFor(ApiServiceMethods)
final apiServiceMethodsProvider =
    AutoDisposeNotifierProvider<ApiServiceMethods, ApiService>.internal(
  ApiServiceMethods.new,
  name: r'apiServiceMethodsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$apiServiceMethodsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ApiServiceMethods = AutoDisposeNotifier<ApiService>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
