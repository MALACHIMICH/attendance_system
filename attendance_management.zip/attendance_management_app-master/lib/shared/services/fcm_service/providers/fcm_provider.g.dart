// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fcm_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$fcmServiceMethodsHash() => r'd9be063092602067e3483ca46e3379b5e6d6749e';

/// See also [FcmServiceMethods].
@ProviderFor(FcmServiceMethods)
final fcmServiceMethodsProvider =
    AutoDisposeNotifierProvider<FcmServiceMethods, FcmService>.internal(
  FcmServiceMethods.new,
  name: r'fcmServiceMethodsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$fcmServiceMethodsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$FcmServiceMethods = AutoDisposeNotifier<FcmService>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
