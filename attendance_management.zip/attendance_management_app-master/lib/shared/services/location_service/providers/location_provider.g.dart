// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'location_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$locationServiceMethodsHash() =>
    r'5a24bf7db61939d362468e215f21bf4ec52ad443';

/// See also [LocationServiceMethods].
@ProviderFor(LocationServiceMethods)
final locationServiceMethodsProvider = AutoDisposeNotifierProvider<
    LocationServiceMethods, LocationService>.internal(
  LocationServiceMethods.new,
  name: r'locationServiceMethodsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$locationServiceMethodsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$LocationServiceMethods = AutoDisposeNotifier<LocationService>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
