// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'saved_info_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$savedInfoServiceMethodsHash() =>
    r'8bf36f64bdc5febd9e1b15a42da6a554fd610683';

/// See also [SavedInfoServiceMethods].
@ProviderFor(SavedInfoServiceMethods)
final savedInfoServiceMethodsProvider = AutoDisposeNotifierProvider<
    SavedInfoServiceMethods, SavedInfoService>.internal(
  SavedInfoServiceMethods.new,
  name: r'savedInfoServiceMethodsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$savedInfoServiceMethodsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SavedInfoServiceMethods = AutoDisposeNotifier<SavedInfoService>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
