// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'local_auth_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$localAuthServiceMethodsHash() =>
    r'1ecd484fdb672116233f134846e10e41762768ec';

/// See also [LocalAuthServiceMethods].
@ProviderFor(LocalAuthServiceMethods)
final localAuthServiceMethodsProvider = AutoDisposeNotifierProvider<
    LocalAuthServiceMethods, LocalAuthService>.internal(
  LocalAuthServiceMethods.new,
  name: r'localAuthServiceMethodsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$localAuthServiceMethodsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$LocalAuthServiceMethods = AutoDisposeNotifier<LocalAuthService>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
