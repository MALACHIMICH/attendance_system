// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_route_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$appRouterHash() => r'f9055b057c96a012de783a06e29544589b373bf1';

/// See also [appRouter].
@ProviderFor(appRouter)
final appRouterProvider = Provider<Raw<AppRouter>>.internal(
  appRouter,
  name: r'appRouterProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$appRouterHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef AppRouterRef = ProviderRef<Raw<AppRouter>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
